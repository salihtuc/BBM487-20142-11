import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Academic {
	String natID, userCode, name, surname, password, dateOfBirth, lineNo,
			mailAddress, degree;
        
        ArrayList<Academic> academics = new ArrayList<Academic>();

	public Academic() {
		super();
	}

	public Academic(String lineNo, String name, String surname, String natID,
			String dateOfBirth, String mailAddress, String userCode,
			String password, String degree) {

		this.lineNo = lineNo;
		this.name = name;
		this.surname = surname;
		this.natID = natID;
		this.dateOfBirth = dateOfBirth;
		this.mailAddress = mailAddress;
		this.userCode = userCode;
		this.password = password;
		this.degree = degree;

	}

	public synchronized void readAcademics(String filename) {
		String fileName = filename;

		

		int k = 1;

		File file = new File(fileName);
		try {
			Scanner oku = new Scanner(file);
			while (oku.hasNext()) {

				String data = oku.nextLine();
				ArrayList<String> AcademicList = new ArrayList<String>(
						Arrays.asList(data.split(";")));

				if (k == 0) {
					Academic academic = new Academic(AcademicList.get(k),
							AcademicList.get(k + 1), AcademicList.get(k + 2),
							AcademicList.get(k + 3), AcademicList.get(k + 4),
							AcademicList.get(k + 5), AcademicList.get(k + 6),
							AcademicList.get(k + 7), AcademicList.get(k + 8));
					
					academics.add(academic);
				}
				k = 0;
			}
			
			/*for(int i = 0; i < academics.size(); i++){
				System.out.println(printAcademic(academics.get(i)));	
			}*/

			oku.close();
		} catch (FileNotFoundException e) {

			//JOptionPane.showMessageDialog(null, "File is not found. Try another file name.");
		}
	}
	
	String printAcademic (Academic a){
		return "Name: " + a.name + " Kimlik: " + a.natID + " Dogum: " + a.dateOfBirth;
	}
	
}
