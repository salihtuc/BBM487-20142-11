import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Course {

	String courseName, opticalCode, courseCode, section, somestre, instCode;
	int teo, prac, credit, akts, capacity;

	public Course() {	//Main'den fonksiyonu cagirmak icin acildi
		super();
	}

	public Course(String courseName, String opticalCode, String courseCode,	//Nesne tanimlamak icin constructor acildi
			String section, String somestre, int teo, int prac, int credit,
			int akts, int capacity, String instCode) {

		this.courseName = courseName;
		this.opticalCode = opticalCode;
		this.courseCode = courseCode;
		this.section = section;
		this.somestre = somestre;
		this.teo = teo;
		this.prac = prac;
		this.credit = credit;
		this.akts = akts;
		this.capacity = capacity;
		this.instCode = instCode;
	}

	public synchronized void readCourses(String filename) {
		String fileName = filename;
		
		ArrayList<Course> courses = new ArrayList<Course>();
		
		int k = 1;	//k kontrol mekanizmasi, ilk satiri atlamak icin.

		File file = new File(fileName);
		try {
			Scanner oku = new Scanner(file);
			while (oku.hasNext()) {

				String data = oku.nextLine();
				ArrayList<String> CourseList = new ArrayList<String>(	//;'e gore ayiriyor. Boylece her kelime bir eleman oluyor.
						Arrays.asList(data.split(";")));
				
				
				
				if (k == 0) {
					Course course = new Course(CourseList.get(k),	//Yeni course nesnesi olusturuyor, yukarida tanimladigimiz degiskenlerle.
							CourseList.get(k + 1), CourseList.get(k + 2),
							CourseList.get(k + 3), CourseList.get( 4),
							Integer.parseInt(CourseList.get(k + 5)),
							Integer.parseInt(CourseList.get(k + 6)),
							Integer.parseInt(CourseList.get(k + 7)),
							Integer.parseInt(CourseList.get(k + 8)),
							Integer.parseInt(CourseList.get(k + 9)),
							CourseList.get(k + 10));

					courses.add(course);	//Olusturulan nesneyi arraylist'e atiyor. Tum dersler tum bilgileriyle su an arraylist'imizde.
				}
				k = 0;
			}
			
			/*for(int i = 0; i < courses.size(); i++){
				System.out.println(printCourse(courses.get(i)));	//Deneme amacli, dersleri yazdiriyor.
			}*/
			
			oku.close();
		} catch (FileNotFoundException e) {

			//JOptionPane.showMessageDialog(null, "File is not found. Try another file name.");
		}
	}
	
	String printCourse (Course c){
		return "Name: " + c.courseName + " Somestre: " + c.somestre;	//Diger degiskenler eklenecek.
	}
	
}
