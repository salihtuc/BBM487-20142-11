
public class Functions {
	
	void updateStudentInfo(Student s, String newMailAddress){
		s.mailAddress = newMailAddress;
	}
	
	void updateAcademicInfo (Academic a, String newMailAddress){
		a.mailAddress = newMailAddress;
	}
	
	void logIn (Student s, String enteredID, String enteredPassword){
		if(s.ID.equals(enteredID) && s.password.equals(enteredPassword)){
			
		}
		else{
			System.out.println("ID or Password did not match. Please try again.");
		}
	}
	
	void logIn (Academic a, String enteredID, String enteredPassword){
		
	}
	
	void forgotPassword (Student s){
		
	}
	
	void forgotPassword (Academic a){
		
	}
	
	void changePassword (Student s, String newPassword){
		
	}
	
	void changePassword (Academic a, String newPassword){
		
	}
	
	void addCourse (Student s, Course c){
		
	}
	
	void dropCourse (Student s, Course c){
		
	}
	
	String studentInfo (Student s){
		return " ";
	}
	
	String academicInfo (Academic a){
		return " ";
	}
	
	String courseInfo (Course c){
		//TODO,
            return " ";
	}
	
	String printCarnet (Student s, String whichSomestre){
		//TODO
            return " ";
	}
	
	String printTranscript (Student s){
		//TODO
            return " ";
	}
	
	boolean isPasswordCorrect (String password, Student s){
		if(s.password.equals(password)){
			return true;
		}
		else
			return false;
	}
	
	boolean isPasswordCorrect (String password, Academic a){
		if(a.password.equals(password)){
			return true;
		}
		else
			return false;
	}
	
	int computeAverageForSomestre (Student s, String whichSomestre){
		//TODO
            return -89;
	}
	
	int computeGeneralAverage (Student s){
		int average;
		
		average = (int) (s.totalScore / s.takingCredit);
		
		return average;
	}
        
        public boolean isValidPassword(Student s, String password){
            int k = 0;
            for(int i = 0; i < s.students.size()-1; i++){
                if(password.equals(s.students.get(i).password)){
                    k = 1;
                }
                else
                    k = 0;
            }
            
            if(k==1)
                return true;
            else
                return false;
        }
        /*
        @override
        */
        public boolean isValidPassword(Academic a, String password){
            int k = 0;
            for(int i = 0; i < a.academics.size(); i++){
                if(password.equals(a.academics.get(i).password)){
                    k = 1;
                }
                else
                    k = 0;
            }
            
            if(k==1)
                return true;
            else
                return false;
        }
        
        public int search(Student s, String ID){
            int i = 0;
            boolean found = false;
            int a = 0;
            
            for(i = 0; i < s.students.size(); i++){
                if(s.students.get(i).ID.equals(ID)){
                    found = true;
                    a = i;
                }
            }
            
            return a;
            
        }
        
}
