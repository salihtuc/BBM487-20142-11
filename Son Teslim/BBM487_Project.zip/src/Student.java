import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;
import javax.swing.JOptionPane;

public class Student {
        
        ArrayList<Student> students = new ArrayList<Student>();
        
        
	String lineNo, ID, name, surname, dateOfBirth, nationality, natID,
			mailAddress, password, consultantCode;
	int takingCredit, passingCredit, year, somestre;
	boolean kayitOnayi, esOnayi, wAKTS;
	double average, totalScore;
        
        boolean b;

	public Student() {
		super();
	}

	public Student(String lineNo, String name, String surname, String natID,
			String mailAddress, String dateOfBirth, String ID, String password,
			int year, int somestre, String consultantCode, String average,
			String kayitOnayis, String esOnayis, String wAKTSs,
			String nationality, int takingCredit, int passingCredit,
			String totalScore) {
		
		average = average.replaceAll(",", ".");
		double avrg = Double.parseDouble(average);
		
		totalScore = totalScore.replaceAll("," , ".");
		double totScore = Double.parseDouble(totalScore);
		
		this.lineNo = lineNo;
		this.ID = ID;
		this.name = name;
		this.surname = surname;
		this.dateOfBirth = dateOfBirth;
		this.nationality = nationality;
		this.natID = natID;
		this.mailAddress = mailAddress;
		this.password = password;
		this.consultantCode = consultantCode;
		this.average = avrg;
		this.takingCredit = takingCredit;
		this.passingCredit = passingCredit;
		this.totalScore = totScore;
		this.year = year;
		this.somestre = somestre;

		if (kayitOnayis.equals("Onaylı") || kayitOnayis.equals("Onayli"))
			kayitOnayi = true;
		else
			kayitOnayi = false;

		if (esOnayis.equals("Onaylı") || esOnayis.equals("Onayli"))
			esOnayi = true;
		else
			esOnayi = false;

		if (wAKTSs.equals("Evet"))
			wAKTS = true;
		else
			wAKTS = false;
	}

    /**
     *
     * @param fileName
     */
    public void readStudents(String fileName) {
		//String fileName = filename;

		//String fileName = "ogrenciler_1.csv";

		int decision = 1;

		File file = new File(fileName);
		try {
                    try (Scanner oku = new Scanner(file)) {
                        while (oku.hasNext()) {
                            
                            String data = oku.nextLine();
                            ArrayList<String> StudentList = new ArrayList<>(
                                    Arrays.asList(data.split(";")));
                            
                            if (decision == 0) {
                                Student theStudent = new Student(StudentList.get(decision),
                                        StudentList.get(decision + 1), StudentList.get(decision + 2),
                                        StudentList.get(decision + 3), StudentList.get(decision + 4),
                                        StudentList.get(decision + 5), StudentList.get(decision + 6),
                                        StudentList.get(decision + 7),
                                        Integer.parseInt(StudentList.get(decision + 8)),
                                        Integer.parseInt(StudentList.get(decision + 9)),
                                        StudentList.get(decision + 10),
                                        StudentList.get(decision + 11),
                                        StudentList.get(decision + 12), StudentList.get(decision + 13),
                                        StudentList.get(decision + 14), StudentList.get(decision + 15),
                                        Integer.parseInt(StudentList.get(decision + 16)),
                                        Integer.parseInt(StudentList.get(decision + 17)),
                                        StudentList.get(decision + 18));
                                
                                students.add(theStudent);
                            }
                            decision = 0;
                        }
                        
                        /*for(int i = 0; i < students.size(); i++){
                        System.out.println(printStudent(students.get(i)));
                        }*/
                        
                        b = decide(students);
                    }
		} catch (FileNotFoundException e) {
                    JOptionPane.showMessageDialog(null, "File is not found. Try another file name.");
		}
	}
	
	String printStudent (Student s){
		return "Name: " + s.name + " AKTS? " + s.wAKTS + " TC: " + s.natID + " average: " + s.average;	//Diger degiskenler eklenecek.
	}
        
        public boolean decide(ArrayList list){
            return list.size() > 0;
        }
}
